// src/pages/HomePage/HomePage.tsx
import React from 'react';

const HomePage: React.FC = () => {
  return (
    <div>
      <h1>Bienvenido a AppCopio</h1>
      <p>Esta es el área de contenido principal. Aquí podríamos mostrar un resumen o noticias.</p>
    </div>
  );
};

export default HomePage;