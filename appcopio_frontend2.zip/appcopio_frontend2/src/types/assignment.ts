export type ActiveAssignment = {
  center_id: string;
  center_name: string;
};