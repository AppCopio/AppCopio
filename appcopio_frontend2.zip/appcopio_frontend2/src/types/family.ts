export type HouseholdData = {
  fibeFolio: string;
  observations: string;
  selectedNeeds: string[]; // usa NEEDS_OPTIONS
};
